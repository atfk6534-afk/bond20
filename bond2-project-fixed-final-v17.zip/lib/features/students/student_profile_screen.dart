import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/database/database.dart';
import '../../core/database/database_provider.dart';
import '../../core/utils/money.dart';
import '../../core/services/contact_service.dart';
import '../grades/grades_repository.dart';
import '../payments/payments_repository.dart';
import '../settings/settings_repository.dart';
import 'students_repository.dart';


Future<void> _shareGuardianReport(BuildContext context, WidgetRef ref, String studentId) async {
  final repo = ref.read(studentsRepositoryProvider);
  final student = await repo.byId(studentId);
  if (student == null) return;

  final balance = await repo.balanceFor(studentId);
  final attendance = await repo.attendanceSummaryFor(studentId);
  final grades = await ref.read(gradesRepositoryProvider).watchForStudent(studentId).first;
  final payments = await ref.read(paymentsRepositoryProvider).watchForStudent(studentId).first;

  String groupName = 'غير محددة';
  if (student.groupId != null) {
    final group = await (ref.read(databaseProvider).select(ref.read(databaseProvider).groups)
          ..where((t) => t.id.equals(student.groupId!)))
        .getSingleOrNull();
    groupName = group?.name ?? groupName;
  }

  final buffer = StringBuffer()
    ..writeln('📋 تقرير الطالب — BOND2')
    ..writeln('الطالب: ${student.name}')
    ..writeln('المجموعة: $groupName')
    ..writeln()
    ..writeln('📅 الحضور والغياب')
    ..writeln('إجمالي الحصص المنتهية/التي بدأ موعدها: ${attendance.total}')
    ..writeln('✅ حاضر: ${attendance.present}')
    ..writeln('❌ غائب: ${attendance.absent}')
    ..writeln('نسبة الحضور: ${attendance.percentage.toStringAsFixed(1)}%')
    ..writeln()
    ..writeln('💰 الحالة المالية')
    ..writeln('إجمالي المستحق: ${Money.format(balance.totalCharged)}')
    ..writeln('إجمالي المدفوع: ${Money.format(balance.totalPaid)}')
    ..writeln('المتبقي: ${Money.format(balance.outstanding < 0 ? 0 : balance.outstanding)}')
    ..writeln()
    ..writeln('📝 درجات الامتحانات');

  if (grades.isEmpty) {
    buffer.writeln('لا توجد درجات مسجلة بعد');
  } else {
    final summary = StudentGradeSummary(grades);
    if (summary.averagePercentage != null) {
      buffer.writeln('المتوسط العام: ${summary.averagePercentage!.toStringAsFixed(1)}%');
    }
    for (final g in grades) {
      buffer.writeln(
        '- ${g.examName}: ${g.score.toStringAsFixed(1)}/${g.maxScore.toStringAsFixed(0)} '
        '(${(g.score / g.maxScore * 100).toStringAsFixed(0)}%)',
      );
    }
  }

  buffer
    ..writeln()
    ..writeln('💳 آخر المدفوعات');
  if (payments.isEmpty) {
    buffer.writeln('لا توجد مدفوعات مسجلة بعد');
  } else {
    for (final payment in payments.take(10)) {
      buffer.writeln(
        '- ${Money.format(payment.amountPiastres)} — '
        '${payment.date.year}/${payment.date.month}/${payment.date.day}',
      );
    }
  }

  final phone = student.guardianPhone ?? student.studentPhone;
  if (phone == null || phone.trim().isEmpty) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا يوجد رقم هاتف لولي الأمر أو الطالب')),
      );
    }
    return;
  }

  final opened = await ContactService.openWhatsApp(phone, buffer.toString());
  if (!opened && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تعذر فتح واتساب')),
    );
  }
}

class StudentProfileScreen extends ConsumerWidget {
  final String studentId;
  const StudentProfileScreen({super.key, required this.studentId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final studentAsync = ref.watch(_studentProvider(studentId));
    final balanceAsync = ref.watch(studentBalanceProvider(studentId));
    final attendanceAsync = ref.watch(studentAttendanceSummaryProvider(studentId));
    final paymentsAsync = ref.watch(_paymentsProvider(studentId));
    final gradesAsync = ref.watch(studentGradesProvider(studentId));

    return Scaffold(
      appBar: AppBar(
        title: studentAsync.when(
          data: (s) => Text(s?.name ?? ''),
          loading: () => const Text(''),
          error: (_, __) => const Text(''),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_rounded),
            onPressed: () => context.push('/students/$studentId/qr'),
          ),
        ],
      ),
      body: studentAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => const Center(child: Text('تعذر تحميل بيانات الطالب')),
        data: (student) {
          if (student == null) return const Center(child: Text('الطالب غير موجود'));
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _InfoSection(
                student: student,
                groupNameAsync: student.groupId == null
                    ? const AsyncValue.data(null)
                    : ref.watch(_studentGroupProvider(student.groupId!)),
              ),
              const SizedBox(height: 16),
              const _SectionTitle('الملخص المالي'),
              balanceAsync.when(
                data: (b) => _FinancialCard(
                  balance: b,
                  studentId: studentId,
                  onPaymentRecorded: () async {
                    await context.push('/payments/record?studentId=$studentId');
                    if (!context.mounted) return;
                    ref.invalidate(studentBalanceProvider(studentId));
                    ref.invalidate(openChargesProvider(studentId));
                    ref.invalidate(_paymentsProvider(studentId));
                  },
                ),
                loading: () => const CircularProgressIndicator(),
                error: (_, __) => const Text('تعذر حساب الرصيد'),
              ),
              const SizedBox(height: 16),
              const _SectionTitle('ملخص الحضور'),
              attendanceAsync.when(
                data: (a) => _AttendanceCard(summary: a),
                loading: () => const CircularProgressIndicator(),
                error: (_, __) => const Text('تعذر تحميل الحضور'),
              ),
              const SizedBox(height: 16),
              const _SectionTitle('سجل المدفوعات'),
              paymentsAsync.when(
                data: (payments) {
                  if (payments.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('لا توجد مدفوعات مسجلة بعد', style: TextStyle(color: Colors.grey)),
                    );
                  }
                  return Column(
                    children: [
                      for (final p in payments)
                        Card(
                          child: ListTile(
                            leading: const Icon(Icons.check_circle_outline_rounded),
                            title: Text(Money.format(p.amountPiastres)),
                            subtitle: Text('${p.date.year}/${p.date.month}/${p.date.day}'),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline_rounded, size: 20),
                              tooltip: 'حذف الدفعة',
                              onPressed: () => _confirmDeletePayment(context, ref, p.id),
                            ),
                          ),
                        ),
                    ],
                  );
                },
                loading: () => const CircularProgressIndicator(),
                error: (_, __) => const Text('تعذر تحميل المدفوعات'),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const _SectionTitle('الدرجات'),
                  TextButton.icon(
                    icon: const Icon(Icons.add_rounded, size: 18),
                    label: const Text('إضافة درجة'),
                    onPressed: () => _showAddGradeSheet(context, ref, studentId),
                  ),
                ],
              ),
              gradesAsync.when(
                data: (grades) {
                  if (grades.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('لا توجد درجات مسجلة بعد', style: TextStyle(color: Colors.grey)),
                    );
                  }
                  final summary = StudentGradeSummary(grades);
                  return Column(
                    children: [
                      if (summary.averagePercentage != null)
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Text(
                              'المتوسط العام: ${summary.averagePercentage!.toStringAsFixed(1)}%'
                              ' (${summary.count} امتحان)',
                              style: const TextStyle(fontWeight: FontWeight.w800),
                            ),
                          ),
                        ),
                      for (final g in grades)
                        Card(
                          child: ListTile(
                            leading: const Icon(Icons.grade_rounded),
                            title: Text(g.examName),
                            subtitle: Text(
                              '${g.score.toStringAsFixed(1)} / ${g.maxScore.toStringAsFixed(0)}'
                              '  •  ${g.date.year}/${g.date.month}/${g.date.day}'
                              '  •  ${(g.score / g.maxScore * 100).toStringAsFixed(0)}%',
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline_rounded, size: 20),
                              onPressed: () async {
                                await ref.read(gradesRepositoryProvider).deleteGrade(g.id);
                              },
                            ),
                          ),
                        ),
                    ],
                  );
                },
                loading: () => const CircularProgressIndicator(),
                error: (_, __) => const Text('تعذر تحميل الدرجات'),
              ),
              const SizedBox(height: 24),
              if (student.guardianPhone != null || student.studentPhone != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      icon: const Icon(Icons.assignment_rounded),
                      label: const Text('إرسال تقرير كامل لولي الأمر'),
                      onPressed: () => _shareGuardianReport(context, ref, studentId),
                    ),
                  ),
                ),
              if (student.guardianPhone != null || student.studentPhone != null)
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.call_rounded),
                        label: const Text('اتصال'),
                        onPressed: () => ContactService.call(
                            (student.guardianPhone ?? student.studentPhone)!),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.chat_rounded),
                        label: const Text('واتساب'),
                        onPressed: () => ContactService.openWhatsApp(
                          (student.guardianPhone ?? student.studentPhone)!,
                          'مرحبًا بخصوص الطالب ${student.name}',
                        ),
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 12),
              TextButton.icon(
                icon: Icon(student.status == StudentStatus.active
                    ? Icons.archive_rounded
                    : Icons.unarchive_rounded),
                label: Text(student.status == StudentStatus.active ? 'أرشفة الطالب' : 'إلغاء الأرشفة'),
                onPressed: () async {
                  await ref.read(studentsRepositoryProvider).setArchived(
                        studentId,
                        student.status == StudentStatus.active,
                      );
                  ref.invalidate(_studentProvider(studentId));
                },
              ),
              TextButton.icon(
                icon: Icon(Icons.delete_forever_rounded, color: Theme.of(context).colorScheme.error),
                label: Text('حذف الطالب نهائيًا',
                    style: TextStyle(color: Theme.of(context).colorScheme.error)),
                onPressed: () => _confirmPermanentDelete(context, ref, student),
              ),
            ],
          );
        },
      ),
    );
  }
}

final _studentGroupProvider = FutureProvider.family<Group?, String>((ref, groupId) {
  final db = ref.watch(databaseProvider);
  return (db.select(db.groups)..where((t) => t.id.equals(groupId))).getSingleOrNull();
});

class _InfoSection extends StatelessWidget {
  final Student student;
  final AsyncValue<Group?> groupNameAsync;
  const _InfoSection({required this.student, required this.groupNameAsync});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (student.grade != null) Text('الصف: ${student.grade}'),
            groupNameAsync.when(
              data: (group) => Text('المجموعة: ${group?.name ?? 'غير محددة'}'),
              loading: () => const Text('المجموعة: ...'),
              error: (_, __) => const Text('المجموعة: غير محددة'),
            ),
            if (student.studentPhone != null) Text('هاتف الطالب: ${student.studentPhone}'),
            if (student.guardianName != null) Text('ولي الأمر: ${student.guardianName}'),
            if (student.guardianPhone != null) Text('هاتف ولي الأمر: ${student.guardianPhone}'),
            if (student.notes != null) Text('ملاحظات: ${student.notes}'),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) =>
      Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(text, style: Theme.of(context).textTheme.titleMedium));
}

class _FinancialCard extends StatelessWidget {
  final StudentBalance balance;
  final String studentId;
  final Future<void> Function() onPaymentRecorded;
  const _FinancialCard({
    required this.balance,
    required this.studentId,
    required this.onPaymentRecorded,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _stat('الإجمالي المستحق', Money.format(balance.totalCharged)),
                _stat('المدفوع', Money.format(balance.totalPaid)),
                _stat('المتبقي', Money.format(balance.outstanding < 0 ? 0 : balance.outstanding)),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: onPaymentRecorded,
                    child: const Text('تسجيل دفعة'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => _showAddChargeDialog(context, studentId),
                    child: const Text('إضافة مستحق'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) => Column(
        children: [
          Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
        ],
      );
}

class _AttendanceCard extends StatelessWidget {
  final AttendanceSummary summary;
  const _AttendanceCard({required this.summary});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _stat('عدد الحصص', '${summary.total}'),
            _stat('حاضر', '${summary.present}'),
            _stat('غائب', '${summary.absent}'),
            _stat('النسبة', '${summary.percentage.toStringAsFixed(0)}%'),
          ],
        ),
      ),
    );
  }

  Widget _stat(String label, String value) => Column(
        children: [
          Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
        ],
      );
}

final _studentProvider = FutureProvider.family((ref, String id) {
  return ref.watch(studentsRepositoryProvider).byId(id);
});

final _paymentsProvider = StreamProvider.family((ref, String studentId) {
  return ref.watch(paymentsRepositoryProvider).watchForStudent(studentId);
});

/// "+ إضافة مستحق" (rule #18 Add Charge) - a manual, one-off charge
/// outside of a lesson/material (e.g. a fine or custom fee).
void _showAddChargeDialog(BuildContext context, String studentId) {
  final descriptionController = TextEditingController();
  final amountController = TextEditingController();
  bool saving = false;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (context) => Consumer(builder: (context, ref, _) {
      return StatefulBuilder(builder: (context, setState) {
        Future<void> submit() async {
          final amount = num.tryParse(amountController.text.trim());
          if (descriptionController.text.trim().isEmpty || amount == null || amount <= 0) {
            ScaffoldMessenger.of(context)
                .showSnackBar(const SnackBar(content: Text('أدخل وصفًا ومبلغًا صحيحًا')));
            return;
          }
          setState(() => saving = true);
          try {
            await ref.read(paymentsRepositoryProvider).addManualCharge(
                  studentId: studentId,
                  description: descriptionController.text.trim(),
                  amountPiastres: Money.egpToPiastres(amount),
                );
            if (context.mounted) Navigator.pop(context);
          } catch (e) {
            setState(() => saving = false);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
            }
          }
        }

        return Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('إضافة مستحق', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              TextField(
                controller: descriptionController,
                decoration: const InputDecoration(labelText: 'الوصف (مثال: غرامة تأخير)'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: amountController,
                decoration: const InputDecoration(labelText: 'المبلغ بالجنيه'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: saving ? null : submit,
                child: saving
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator())
                    : const Text('حفظ المستحق'),
              ),
            ],
          ),
        );
      });
    }),
  );
}

Future<void> _confirmDeletePayment(BuildContext context, WidgetRef ref, String paymentId) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('حذف الدفعة؟'),
      content: const Text(
        'سيعود المبلغ المرتبط بهذه الدفعة "غير مدفوع" على الطالب مرة أخرى. '
        'هذا الإجراء لا يمكن التراجع عنه.',
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
      ],
    ),
  );
  if (confirmed != true) return;
  await ref.read(paymentsRepositoryProvider).deletePayment(paymentId);
}

Future<void> _confirmPermanentDelete(BuildContext context, WidgetRef ref, Student student) async {
  final nameController = TextEditingController();
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (context) => StatefulBuilder(builder: (context, setState) {
      final matches = nameController.text.trim() == student.name;
      return AlertDialog(
        title: const Text('حذف الطالب نهائيًا؟'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'سيتم حذف الطالب وكل بياناته نهائيًا: الحضور، المدفوعات، المستحقات، '
              'الدرجات، والمشتريات. هذا الإجراء لا يمكن التراجع عنه إطلاقًا.\n\n'
              'إذا كان الطالب انتقل لمكان آخر فقط، استخدم "أرشفة" بدلًا من هذا.\n\n'
              'اكتب اسم الطالب للتأكيد:',
            ),
            const SizedBox(height: 8),
            TextField(
              controller: nameController,
              decoration: InputDecoration(hintText: student.name),
              onChanged: (_) => setState(() {}),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Theme.of(context).colorScheme.error),
            onPressed: matches ? () => Navigator.pop(context, true) : null,
            child: const Text('حذف نهائيًا'),
          ),
        ],
      );
    }),
  );
  if (confirmed != true) return;
  await ref.read(studentsRepositoryProvider).permanentlyDeleteStudent(student.id);
  if (context.mounted) context.pop();
}

/// Quick "+ إضافة درجة" bottom sheet (rule #1 - 2-tap philosophy),
/// consistent with the add-group/add-material patterns used elsewhere.
void _showAddGradeSheet(BuildContext context, WidgetRef ref, String studentId) {
  final examNameController = TextEditingController();
  final scoreController = TextEditingController();
  final maxScoreController = TextEditingController(text: '100');
  DateTime date = DateTime.now();
  String? subjectId;
  bool saving = false;

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (context) => Consumer(builder: (context, ref, _) {
      final subjects = ref.watch(subjectsProvider);
      return StatefulBuilder(builder: (context, setState) {
        Future<void> submit() async {
          final score = double.tryParse(scoreController.text.trim());
          final maxScore = double.tryParse(maxScoreController.text.trim()) ?? 100;
          if (examNameController.text.trim().isEmpty || score == null) {
            ScaffoldMessenger.of(context)
                .showSnackBar(const SnackBar(content: Text('أدخل اسم الامتحان والدرجة')));
            return;
          }
          setState(() => saving = true);
          try {
            await ref.read(gradesRepositoryProvider).addGrade(
                  studentId: studentId,
                  subjectId: subjectId,
                  examName: examNameController.text.trim(),
                  date: date,
                  score: score,
                  maxScore: maxScore,
                );
            if (context.mounted) Navigator.pop(context);
          } on ArgumentError catch (e) {
            setState(() => saving = false);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message.toString())));
            }
          }
        }

        return Padding(
          padding: EdgeInsets.only(
            left: 20, right: 20, top: 20,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('إضافة درجة امتحان', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              TextField(
                controller: examNameController,
                decoration: const InputDecoration(labelText: 'اسم الامتحان (مثال: امتحان الشهر)'),
              ),
              const SizedBox(height: 12),
              subjects.when(
                data: (list) => DropdownButtonFormField<String>(
                  value: subjectId,
                  decoration: const InputDecoration(labelText: 'المادة (اختياري)'),
                  items: [for (final s in list) DropdownMenuItem(value: s.id, child: Text(s.name))],
                  onChanged: (v) => subjectId = v,
                ),
                loading: () => const SizedBox.shrink(),
                error: (_, __) => const SizedBox.shrink(),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: scoreController,
                      decoration: const InputDecoration(labelText: 'الدرجة'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextField(
                      controller: maxScoreController,
                      decoration: const InputDecoration(labelText: 'من (النهائية)'),
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('التاريخ'),
                subtitle: Text('${date.year}/${date.month}/${date.day}'),
                trailing: const Icon(Icons.calendar_today_rounded),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context, initialDate: date,
                    firstDate: DateTime(2020), lastDate: DateTime(2100),
                  );
                  if (picked != null) setState(() => date = picked);
                },
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: saving ? null : submit,
                child: saving
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator())
                    : const Text('حفظ الدرجة'),
              ),
            ],
          ),
        );
      });
    }),
  );
}
