import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/database/database.dart';
import '../../core/database/database_provider.dart';
import '../grades/grades_repository.dart';
import '../materials/materials_repository.dart';
import '../students/students_repository.dart';
import '../../core/utils/lesson_time.dart';

class ReportFilters {
  final DateTime? from;
  final DateTime? to;
  final String? academicYearId;
  final String? groupId;
  const ReportFilters({this.from, this.to, this.academicYearId, this.groupId});

  ReportFilters copyWith({
    DateTime? from,
    DateTime? to,
    String? academicYearId,
    String? groupId,
    bool clearFrom = false,
    bool clearTo = false,
    bool clearYear = false,
    bool clearGroup = false,
  }) {
    return ReportFilters(
      from: clearFrom ? null : (from ?? this.from),
      to: clearTo ? null : (to ?? this.to),
      academicYearId: clearYear ? null : (academicYearId ?? this.academicYearId),
      groupId: clearGroup ? null : (groupId ?? this.groupId),
    );
  }
}

class StudentAttendanceRow {
  final Student student;
  final int total;
  final int present;
  final int absent;
  const StudentAttendanceRow({
    required this.student,
    required this.total,
    required this.present,
    required this.absent,
  });
  double get percentage => total == 0 ? 0 : (present / total) * 100;
}

class StudentOutstandingRow {
  final Student student;
  final int outstanding;
  const StudentOutstandingRow({required this.student, required this.outstanding});
}

class StudentFinancialRow {
  final Student student;
  final StudentBalance balance;
  const StudentFinancialRow({required this.student, required this.balance});
}

class FinancialSummary {
  final int chargedInRange;
  final int lessonCharges;
  final int materialCharges;
  final int otherCharges;
  final int collectedInRange;
  final int outstandingAllTime;
  const FinancialSummary({
    required this.chargedInRange,
    required this.lessonCharges,
    required this.materialCharges,
    required this.otherCharges,
    required this.collectedInRange,
    required this.outstandingAllTime,
  });
}

class MaterialSalesRow {
  final MaterialItem material;
  final MaterialSalesReport report;
  const MaterialSalesRow({required this.material, required this.report});
}

class StudentGradesRow {
  final Student student;
  final int examCount;
  final double? averagePercentage;
  const StudentGradesRow({
    required this.student,
    required this.examCount,
    required this.averagePercentage,
  });
}

/// Aggregates data across Students/Lessons/Attendance/Charges/Payments/
/// Materials/ExamGrades for the unified Reports screen (rule #50, fix
/// #6). All numbers are always derived live from the same source-of-
/// truth tables the rest of the app uses (rule #6) — nothing here is a
/// separately cached figure that could drift out of sync.
class ReportsRepository {
  final AppDatabase db;
  final StudentsRepository studentsRepo;
  final MaterialsRepository materialsRepo;
  ReportsRepository(this.db, this.studentsRepo, this.materialsRepo);

  Future<List<Student>> _filteredActiveStudents(ReportFilters f) {
    final q = db.select(db.students)..where((t) => t.status.equalsValue(StudentStatus.active));
    if (f.academicYearId != null) {
      q.where((t) => t.academicYearId.equals(f.academicYearId!));
    }
    if (f.groupId != null) {
      q.where((t) => t.groupId.equals(f.groupId!));
    }
    return q.get();
  }

  /// Attendance + absence report (rule #50 "Attendance Report").
  ///
  /// IMPORTANT (historical correctness fix): the STUDENT-level filter
  /// (via [_filteredActiveStudents]) only controls WHICH students are
  /// listed in the report (e.g. "everyone currently in Group B"). Each
  /// listed student's attendance COUNTS are always scoped separately by
  /// the LESSON's own academicYearId/groupId at the time that lesson
  /// happened - never by the student's CURRENT academicYearId/groupId.
  /// Lessons carry their own group/year because a student can move
  /// between groups over time (rule #44) while their past attendance
  /// must stay attached to the group it actually happened in. Filtering
  /// only by the student's current group would incorrectly pull a
  /// student's OLD group's attendance into their NEW group's report.
  Future<List<StudentAttendanceRow>> attendanceReport(ReportFilters f) async {
    final students = await _filteredActiveStudents(f);
    final rows = <StudentAttendanceRow>[];

    for (final s in students) {
      final query = db.select(db.lessonStudents).join([
        innerJoin(db.lessons, db.lessons.id.equalsExp(db.lessonStudents.lessonId)),
      ])..where(db.lessonStudents.studentId.equals(s.id));

      if (f.from != null) query.where(db.lessons.date.isBiggerOrEqualValue(f.from!));
      if (f.to != null) query.where(db.lessons.date.isSmallerThanValue(f.to!));
      if (f.academicYearId != null) {
        query.where(db.lessons.academicYearId.equals(f.academicYearId!));
      }
      if (f.groupId != null) {
        query.where(db.lessons.groupId.equals(f.groupId!));
      }

      final lessonRows = await query.get();
      var total = 0;
      var present = 0;

      for (final row in lessonRows) {
        final lesson = row.readTable(db.lessons);
        if (!lessonHasStarted(lesson)) continue;
        total++;

        final attendance = await (db.select(db.attendanceRecords)
              ..where((t) =>
                  t.lessonId.equals(lesson.id) & t.studentId.equals(s.id)))
            .getSingleOrNull();
        if (attendance?.status == AttendanceStatus.present) present++;
      }

      rows.add(StudentAttendanceRow(
        student: s,
        total: total,
        present: present,
        absent: total - present,
      ));
    }

    rows.sort((a, b) => b.absent.compareTo(a.absent));
    return rows;
  }

  /// Payments report — every payment recorded in the date range, scoped
  /// to students matching the academic year / group filters when set
  /// (rule #50). A payment itself has no single inherent "group" of its
  /// own (one payment can settle charges from several different lessons
  /// or materials via PaymentAllocations), so - consistent with
  /// [outstandingBalancesReport] and [studentFinancialSummaries] in this
  /// same class - the group/year filter here scopes by the paying
  /// STUDENT's current group/year rather than by any single charge.
  Future<List<Payment>> paymentsReport(ReportFilters f) async {
    final q = db.select(db.payments);
    if (f.from != null) q.where((t) => t.date.isBiggerOrEqualValue(f.from!));
    if (f.to != null) q.where((t) => t.date.isSmallerThanValue(f.to!));

    if (f.academicYearId != null || f.groupId != null) {
      final students = await _filteredActiveStudents(f);
      if (students.isEmpty) return [];
      final ids = students.map((s) => s.id).toList();
      q.where((t) => t.studentId.isIn(ids));
    }

    q.orderBy([(t) => OrderingTerm.desc(t.date)]);
    return q.get();
  }

  /// Outstanding balances report (rule #48/#50), filterable by academic
  /// year and group.
  Future<List<StudentOutstandingRow>> outstandingBalancesReport(ReportFilters f) async {
    final students = await _filteredActiveStudents(f);
    final rows = <StudentOutstandingRow>[];
    for (final s in students) {
      final balance = await studentsRepo.balanceFor(s.id);
      if (balance.outstanding > 0) {
        rows.add(StudentOutstandingRow(student: s, outstanding: balance.outstanding));
      }
    }
    rows.sort((a, b) => b.outstanding.compareTo(a.outstanding));
    return rows;
  }

  /// Per-student full financial summary (rule #50 "Student Report").
  Future<List<StudentFinancialRow>> studentFinancialSummaries(ReportFilters f) async {
    final students = await _filteredActiveStudents(f);
    final rows = <StudentFinancialRow>[];
    for (final s in students) {
      final balance = await studentsRepo.balanceFor(s.id);
      rows.add(StudentFinancialRow(student: s, balance: balance));
    }
    return rows;
  }

  /// Materials/books sales report across every material (rule #41/#50).
  Future<List<MaterialSalesRow>> materialSalesReport() async {
    final materials = await materialsRepo.watchAll().first;
    final rows = <MaterialSalesRow>[];
    for (final m in materials) {
      final report = await materialsRepo.salesReportFor(m.id);
      if (report.count > 0) {
        rows.add(MaterialSalesRow(material: m, report: report));
      }
    }
    return rows;
  }

  /// Exam grades report (average percentage per student), scoped by the
  /// SAME historical-correctness rule as [attendanceReport]: each grade
  /// record carries its own academicYearId/groupId snapshot from when it
  /// was recorded, so filtering by group/year here reflects what group
  /// the student was actually in for that exam - never their current
  /// group/year pointer. See ExamGrades' table doc comment and
  /// attendanceReport's doc comment for the full rationale.
  Future<List<StudentGradesRow>> gradesReport(ReportFilters f) async {
    final students = await _filteredActiveStudents(f);
    final rows = <StudentGradesRow>[];

    for (final s in students) {
      final query = db.select(db.examGrades)..where((t) => t.studentId.equals(s.id));
      if (f.from != null) query.where((t) => t.date.isBiggerOrEqualValue(f.from!));
      if (f.to != null) query.where((t) => t.date.isSmallerThanValue(f.to!));
      if (f.academicYearId != null) {
        query.where((t) => t.academicYearId.equals(f.academicYearId!));
      }
      if (f.groupId != null) {
        query.where((t) => t.groupId.equals(f.groupId!));
      }

      final grades = await query.get();
      final summary = StudentGradeSummary(grades);
      rows.add(StudentGradesRow(
        student: s,
        examCount: summary.count,
        averagePercentage: summary.averagePercentage,
      ));
    }

    // Students with recorded exams first, lowest average first (the
    // ones most likely to need attention surface at the top).
    rows.sort((a, b) {
      if (a.averagePercentage == null && b.averagePercentage == null) return 0;
      if (a.averagePercentage == null) return 1;
      if (b.averagePercentage == null) return -1;
      return a.averagePercentage!.compareTo(b.averagePercentage!);
    });
    return rows;
  }

  /// Overall financial summary for the whole filtered cohort (rule #50
  /// "Financial Report"). `chargedInRange` sums Charges CREATED within
  /// [from, to); `collectedInRange` sums Payments RECORDED within the
  /// same window (a payment can settle a charge from before the window,
  /// so these two figures intentionally describe different things and
  /// are labelled separately in the UI rather than implied to net out
  /// to the same total).
  Future<FinancialSummary> financialSummary(ReportFilters f) async {
    final students = await _filteredActiveStudents(f);
    final studentIds = students.map((s) => s.id).toList();

    var chargedTotal = 0, lessonTotal = 0, materialTotal = 0, otherTotal = 0;
    for (final s in students) {
      final chargesQuery = db.select(db.charges)..where((t) => t.studentId.equals(s.id));
      if (f.from != null) chargesQuery.where((t) => t.date.isBiggerOrEqualValue(f.from!));
      if (f.to != null) chargesQuery.where((t) => t.date.isSmallerThanValue(f.to!));
      final charges = await chargesQuery.get();
      for (final c in charges) {
        // A scheduled lesson is not a current financial obligation until
        // its start date/time arrives. Keep future lesson charges out of
        // financial totals just like the student balance/payment screens.
        if (c.sourceType == ChargeSourceType.lesson && c.date.isAfter(DateTime.now())) {
          continue;
        }
        chargedTotal += c.amountPiastres;
        switch (c.sourceType) {
          case ChargeSourceType.lesson:
            lessonTotal += c.amountPiastres;
            break;
          case ChargeSourceType.material:
            materialTotal += c.amountPiastres;
            break;
          case ChargeSourceType.other:
            otherTotal += c.amountPiastres;
            break;
        }
      }
    }

    var collectedTotal = 0;
    if (studentIds.isNotEmpty) {
      final paymentsQuery = db.select(db.payments)..where((t) => t.studentId.isIn(studentIds));
      if (f.from != null) paymentsQuery.where((t) => t.date.isBiggerOrEqualValue(f.from!));
      if (f.to != null) paymentsQuery.where((t) => t.date.isSmallerThanValue(f.to!));
      final payments = await paymentsQuery.get();
      collectedTotal = payments.fold<int>(0, (sum, p) => sum + p.amountPiastres);
    }

    var outstandingTotal = 0;
    for (final s in students) {
      final balance = await studentsRepo.balanceFor(s.id);
      if (balance.outstanding > 0) outstandingTotal += balance.outstanding;
    }

    return FinancialSummary(
      chargedInRange: chargedTotal,
      lessonCharges: lessonTotal,
      materialCharges: materialTotal,
      otherCharges: otherTotal,
      collectedInRange: collectedTotal,
      outstandingAllTime: outstandingTotal,
    );
  }
}

final reportsRepositoryProvider = Provider<ReportsRepository>((ref) {
  return ReportsRepository(
    ref.watch(databaseProvider),
    ref.watch(studentsRepositoryProvider),
    ref.watch(materialsRepositoryProvider),
  );
});
