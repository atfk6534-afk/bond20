import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/database/database.dart';
import '../../core/database/database_provider.dart';
import '../../core/utils/id_generator.dart';
import '../../core/utils/lesson_time.dart';

enum ScanOutcome { recorded, alreadyRecorded, invalidQr, studentNotInLesson, lessonNotStarted }

class ScanResult {
  final ScanOutcome outcome;
  final Student? student;
  const ScanResult(this.outcome, [this.student]);
}

class AttendanceRepository {
  final AppDatabase db;
  AttendanceRepository(this.db);

  Future<bool> _isStudentInLesson(String lessonId, String studentId) async {
    final row = await (db.select(db.lessonStudents)
          ..where((t) => t.lessonId.equals(lessonId) & t.studentId.equals(studentId)))
        .getSingleOrNull();
    return row != null;
  }

  Future<AttendanceRecord?> _existingRecord(String lessonId, String studentId) {
    return (db.select(db.attendanceRecords)
          ..where((t) => t.lessonId.equals(lessonId) & t.studentId.equals(studentId)))
        .getSingleOrNull();
  }

  /// Adds a student who scanned a valid QR but isn't on the lesson
  /// roster yet — only when the teacher explicitly confirms (rule #26).
  Future<void> addStudentToLesson(String lessonId, String studentId, int pricePiastres) async {
    final lesson = await (db.select(db.lessons)..where((t) => t.id.equals(lessonId)))
        .getSingleOrNull();
    if (lesson == null) throw StateError('الحصة غير موجودة');
    if (!lessonHasStarted(lesson)) {
      throw StateError('لا يمكن إضافة طالب للحضور قبل موعد بداية الحصة');
    }

    await db.transaction(() async {
      final lessonStudentId = IdGenerator.newId();
      await db.into(db.lessonStudents).insert(LessonStudentsCompanion.insert(
            id: lessonStudentId,
            lessonId: lessonId,
            studentId: studentId,
            priceAtLessonPiastres: pricePiastres,
          ));
    });
  }

  /// Core QR scan handler (rules #23-#26). Never throws for bad input —
  /// always returns a clear outcome so the scanner UI can keep running.
  Future<ScanResult> handleScan({
    required String rawQrPayload,
    required String lessonId,
    required String? Function(String raw) decode,
    bool autoPayOnAttendance = false,
  }) async {
    final studentId = decode(rawQrPayload);
    if (studentId == null) {
      return const ScanResult(ScanOutcome.invalidQr);
    }

    final student =
        await (db.select(db.students)..where((t) => t.id.equals(studentId)))
            .getSingleOrNull();
    if (student == null) {
      return const ScanResult(ScanOutcome.invalidQr);
    }

    final lesson = await (db.select(db.lessons)..where((t) => t.id.equals(lessonId)))
        .getSingleOrNull();
    if (lesson == null) {
      return const ScanResult(ScanOutcome.invalidQr);
    }
    if (!lessonHasStarted(lesson)) {
      return ScanResult(ScanOutcome.lessonNotStarted, student);
    }

    final inLesson = await _isStudentInLesson(lessonId, studentId);
    if (!inLesson) {
      return ScanResult(ScanOutcome.studentNotInLesson, student);
    }

    final existing = await _existingRecord(lessonId, studentId);
    if (existing != null) {
      return ScanResult(ScanOutcome.alreadyRecorded, student);
    }

    await markAttendance(
      lessonId: lessonId,
      studentId: studentId,
      status: AttendanceStatus.present,
      method: AttendanceMethod.qr,
      autoPayOnAttendance: autoPayOnAttendance,
    );
    return ScanResult(ScanOutcome.recorded, student);
  }

  /// Manual present/absent toggle (rule #27). Upserts — re-marking a
  /// student simply updates their existing record rather than
  /// duplicating it.
  ///
  /// If [autoPayOnAttendance] is true AND [status] is
  /// [AttendanceStatus.present], this also auto-settles that lesson's
  /// charge for the student in the SAME transaction (explicit user
  /// request: "طالما حضر يبقى دفع" - attendance implies payment, so the
  /// teacher doesn't need a separate Record Payment step every lesson).
  /// This is always a FULL payment of exactly the charge's remaining
  /// balance (never more, matching the same strict allocation rule used
  /// everywhere else in the app - see PaymentsRepository.recordPayment),
  /// and is a safe no-op if there is no charge, it's already fully
  /// paid, or the remaining balance is zero/negative.
  Future<void> markAttendance({
    required String lessonId,
    required String studentId,
    required AttendanceStatus status,
    required AttendanceMethod method,
    bool autoPayOnAttendance = false,
  }) async {
    final lesson = await (db.select(db.lessons)..where((t) => t.id.equals(lessonId)))
        .getSingleOrNull();
    if (lesson == null) {
      throw StateError('الحصة غير موجودة');
    }
    if (!lessonHasStarted(lesson)) {
      throw StateError('لا يمكن تسجيل الحضور قبل موعد بداية الحصة');
    }

    await db.transaction(() async {
      final existing = await _existingRecord(lessonId, studentId);
      if (existing != null) {
        await (db.update(db.attendanceRecords)..where((t) => t.id.equals(existing.id)))
            .write(AttendanceRecordsCompanion(
          status: Value(status),
          method: Value(method),
          recordedAt: Value(DateTime.now()),
        ));
      } else {
        await db.into(db.attendanceRecords).insert(AttendanceRecordsCompanion.insert(
              id: IdGenerator.newId(),
              lessonId: lessonId,
              studentId: studentId,
              status: status,
              method: method,
            ));
      }

      if (status == AttendanceStatus.present) {
        await _ensureLessonCharge(lessonId: lessonId, studentId: studentId);
        if (autoPayOnAttendance) {
          await _autoPayLessonCharge(lessonId: lessonId, studentId: studentId);
        }
      }
    });
  }

  Future<void> _ensureLessonCharge({
    required String lessonId,
    required String studentId,
  }) async {
    final lessonStudent = await (db.select(db.lessonStudents)
          ..where((t) =>
              t.lessonId.equals(lessonId) &
              t.studentId.equals(studentId)))
        .getSingleOrNull();
    if (lessonStudent == null || lessonStudent.priceAtLessonPiastres <= 0) return;

    final existing = await (db.select(db.charges)
          ..where((t) =>
              t.sourceId.equals(lessonStudent.id) &
              t.sourceType.equalsValue(ChargeSourceType.lesson)))
        .getSingleOrNull();
    if (existing != null) return;

    final lesson = await (db.select(db.lessons)..where((t) => t.id.equals(lessonId)))
        .getSingle();

    await db.into(db.charges).insert(ChargesCompanion.insert(
          id: IdGenerator.newId(),
          studentId: studentId,
          sourceType: ChargeSourceType.lesson,
          sourceId: Value(lessonStudent.id),
          description: Value(lesson.name ?? 'حصة بتاريخ ${lesson.date.toIso8601String().split('T').first}'),
          amountPiastres: lessonStudent.priceAtLessonPiastres,
          date: Value(lesson.date),
        ));
  }

  /// Auto-settles the Charge tied to this student's membership in this
  /// lesson (via LessonStudents), if any remains unpaid. Idempotent: if
  /// there's no charge, or it's already fully paid (e.g. the teacher
  /// already recorded a manual payment, or attendance is being toggled
  /// present/absent/present again), this does nothing rather than
  /// creating a duplicate or overpaying payment.
  Future<void> _autoPayLessonCharge({
    required String lessonId,
    required String studentId,
  }) async {
    final lessonStudent = await (db.select(db.lessonStudents)
          ..where((t) => t.lessonId.equals(lessonId) & t.studentId.equals(studentId)))
        .getSingleOrNull();
    if (lessonStudent == null) return;

    final charge = await (db.select(db.charges)
          ..where((t) => t.sourceId.equals(lessonStudent.id) & t.sourceType.equalsValue(ChargeSourceType.lesson)))
        .getSingleOrNull();
    if (charge == null) return; // free lesson (price 0) - nothing to pay

    final sum = db.paymentAllocations.amountPiastres.sum();
    final query = db.selectOnly(db.paymentAllocations)
      ..addColumns([sum])
      ..where(db.paymentAllocations.chargeId.equals(charge.id));
    final paidSoFar = (await query.getSingle()).read(sum) ?? 0;

    final remaining = charge.amountPiastres - paidSoFar;
    if (remaining <= 0) return; // already fully paid - safe no-op

    final paymentId = IdGenerator.newId();
    await db.into(db.payments).insert(PaymentsCompanion.insert(
          id: paymentId,
          studentId: studentId,
          amountPiastres: remaining,
          notes: const Value('دفع تلقائي عند تسجيل الحضور'),
        ));
    await db.into(db.paymentAllocations).insert(PaymentAllocationsCompanion.insert(
          id: IdGenerator.newId(),
          paymentId: paymentId,
          chargeId: charge.id,
          amountPiastres: remaining,
        ));
  }

  Stream<List<AttendanceRecord>> watchForLesson(String lessonId) {
    return (db.select(db.attendanceRecords)
          ..where((t) => t.lessonId.equals(lessonId)))
        .watch();
  }
}

final attendanceRepositoryProvider = Provider<AttendanceRepository>((ref) {
  return AttendanceRepository(ref.watch(databaseProvider));
});
