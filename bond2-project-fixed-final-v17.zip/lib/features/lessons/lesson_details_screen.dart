import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/database/database.dart';
import '../../core/utils/money.dart';
import '../../core/utils/lesson_time.dart';
import '../../shared/widgets/status_badge.dart';
import '../attendance/attendance_repository.dart';
import '../settings/settings_repository.dart';
import 'lessons_repository.dart';

class LessonDetailsScreen extends ConsumerWidget {
  final String lessonId;
  const LessonDetailsScreen({super.key, required this.lessonId});

  Future<void> _shareAttendanceRecord(
    BuildContext context,
    WidgetRef ref,
    List<LessonRosterEntry> roster,
  ) async {
    // A simple, real, shareable text summary (rule: attendance record +
    // ability to share it). Built from the same roster data shown on
    // screen, so it can never drift from what the teacher sees.
    final present = roster.where((e) => e.attendanceStatus == AttendanceStatus.present).toList();
    final absent = roster.where((e) => e.attendanceStatus == AttendanceStatus.absent).toList();
    final notRecorded =
        roster.where((e) => e.attendanceStatus == null).toList();

    final buffer = StringBuffer()
      ..writeln('سجل الحضور — BOND2')
      ..writeln('التاريخ: ${DateTime.now().year}/${DateTime.now().month}/${DateTime.now().day}')
      ..writeln()
      ..writeln('✅ الحاضرون (${present.length}):');
    for (final e in present) {
      buffer.writeln('- ${e.student.name}');
    }
    buffer.writeln();
    buffer.writeln('❌ الغائبون (${absent.length}):');
    for (final e in absent) {
      buffer.writeln('- ${e.student.name}');
    }
    if (notRecorded.isNotEmpty) {
      buffer.writeln();
      buffer.writeln('⏳ لم يُسجَّل بعد (${notRecorded.length}):');
      for (final e in notRecorded) {
        buffer.writeln('- ${e.student.name}');
      }
    }

    await Share.share(buffer.toString());
  }

  Future<void> _confirmDeleteLesson(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف الحصة؟'),
        content: const Text(
          'سيتم حذف الحصة وسجل حضورها. لن يُسمح بالحذف إذا كانت هناك '
          'مدفوعات مسجلة مرتبطة بها (لحماية السجل المالي).',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (confirmed != true) return;

    final result = await ref.read(lessonsRepositoryProvider).deleteLesson(lessonId);
    if (!context.mounted) return;
    if (result.success) {
      context.pop();
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(result.error ?? 'تعذر حذف الحصة')));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final rosterAsync = ref.watch(lessonRosterProvider(lessonId));
    final lessonAsync = ref.watch(lessonProvider(lessonId));
    final lesson = lessonAsync.valueOrNull;
    final attendanceEnabled = lesson != null && lessonHasStarted(lesson);

    return Scaffold(
      appBar: AppBar(
        title: const Text('تفاصيل الحصة'),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_scanner_rounded),
            tooltip: attendanceEnabled ? 'بدء الحضور' : 'لم تبدأ الحصة بعد',
            onPressed: attendanceEnabled ? () => context.push('/lessons/$lessonId/attendance') : null,
          ),
          IconButton(
            icon: const Icon(Icons.ios_share_rounded),
            tooltip: 'مشاركة سجل الحضور',
            onPressed: () async {
              final roster = rosterAsync.valueOrNull;
              if (roster != null) await _shareAttendanceRecord(context, ref, roster);
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            tooltip: 'حذف الحصة',
            onPressed: () => _confirmDeleteLesson(context, ref),
          ),
        ],
      ),
      body: rosterAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => const Center(child: Text('تعذر تحميل بيانات الحصة')),
        data: (roster) {
          if (roster.isEmpty) {
            return const Center(child: Text('لا يوجد طلاب في هذه الحصة بعد'));
          }
          return ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
            itemCount: roster.length + (attendanceEnabled ? 0 : 1),
            itemBuilder: (context, i) {
              if (!attendanceEnabled && i == 0) {
                return Card(
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  child: const Padding(
                    padding: EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Icon(Icons.schedule_rounded),
                        SizedBox(width: 10),
                        Expanded(child: Text('هذه الحصة لم تبدأ بعد. لا يمكن تسجيل حضور أو دفع تلقائي قبل موعدها.')),
                      ],
                    ),
                  ),
                );
              }
              final rosterIndex = attendanceEnabled ? i : i - 1;
              return _RosterTile(
                entry: roster[rosterIndex],
                lessonId: lessonId,
                attendanceEnabled: attendanceEnabled,
              );
            },
          );
        },
      ),
    );
  }
}

class _RosterTile extends ConsumerWidget {
  final LessonRosterEntry entry;
  final String lessonId;
  final bool attendanceEnabled;
  const _RosterTile({required this.entry, required this.lessonId, required this.attendanceEnabled});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final attendanceRepo = ref.read(attendanceRepositoryProvider);

    final isPresent = entry.attendanceStatus == AttendanceStatus.present;
    final isAbsent = entry.attendanceStatus == AttendanceStatus.absent ||
        (attendanceEnabled && entry.attendanceStatus == null);
    final borderColor = isPresent
        ? Colors.green
        : isAbsent
            ? Colors.red
            : Colors.transparent;

    return Card(
      elevation: isPresent ? 4 : 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: borderColor,
          width: isPresent || isAbsent ? 2.5 : 0,
        ),
      ),
      color: isPresent
          ? Colors.green.withOpacity(0.10)
          : isAbsent
              ? Colors.red.withOpacity(0.06)
              : null,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(entry.student.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                ),
                if (isPresent)
                  const Chip(
                    avatar: Icon(Icons.check_circle_rounded, size: 18, color: Colors.white),
                    label: Text('حاضر', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                    backgroundColor: Colors.green,
                    visualDensity: VisualDensity.compact,
                  )
                else if (isAbsent)
                  const Chip(
                    avatar: Icon(Icons.cancel_rounded, size: 18, color: Colors.white),
                    label: Text('غائب', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                    backgroundColor: Colors.red,
                    visualDensity: VisualDensity.compact,
                  )
                else
                  const Chip(
                    label: Text('لم تبدأ الحصة'),
                    visualDensity: VisualDensity.compact,
                  ),
                const SizedBox(width: 6),
                if (entry.chargeIssued)
                  StatusBadge(
                    status: paymentStatusFor(charged: entry.chargeAmount, paid: entry.paidForCharge),
                  )
                else
                  const Chip(
                    label: Text('غير مستحق بعد'),
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
            if (isPresent)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(top: 4, bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.check_circle_rounded, color: Colors.green, size: 20),
                    SizedBox(width: 8),
                    Text('حضر الحصة ✓', style: TextStyle(color: Colors.green, fontWeight: FontWeight.w900)),
                  ],
                ),
              ),
            const SizedBox(height: 4),
            Text(
              entry.chargeIssued
                  ? 'المتبقي: ${Money.format(entry.remaining < 0 ? 0 : entry.remaining)}'
                  : 'قيمة الحصة: ${Money.format(entry.lessonPrice)} — لا تُحتسب كمستحق إلا بعد تسجيل الحضور',
              style: const TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: Icon(Icons.check_circle_rounded,
                        color: entry.attendanceStatus == AttendanceStatus.present ? Colors.green : null),
                    label: const Text('حاضر'),
                    style: isPresent
                        ? OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.green, width: 2),
                            foregroundColor: Colors.green,
                          )
                        : null,
                    onPressed: !attendanceEnabled ? null : () async {
                      final autoPay =
                          ref.read(appSettingsProvider).valueOrNull?.autoPayOnAttendance ?? false;
                      await attendanceRepo.markAttendance(
                        lessonId: lessonId,
                        studentId: entry.student.id,
                        status: AttendanceStatus.present,
                        method: AttendanceMethod.manual,
                        autoPayOnAttendance: autoPay,
                      );
                      ref.invalidate(lessonRosterProvider(lessonId));
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: Icon(Icons.cancel_rounded,
                        color: entry.attendanceStatus == AttendanceStatus.absent ? Colors.red : null),
                    label: const Text('غائب'),
                    style: isAbsent
                        ? OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.red, width: 2),
                            foregroundColor: Colors.red,
                          )
                        : null,
                    onPressed: !attendanceEnabled ? null : () async {
                      await attendanceRepo.markAttendance(
                        lessonId: lessonId,
                        studentId: entry.student.id,
                        status: AttendanceStatus.absent,
                        method: AttendanceMethod.manual,
                      );
                      ref.invalidate(lessonRosterProvider(lessonId));
                    },
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.payments_rounded),
                  onPressed: () => context.push('/payments/record?studentId=${entry.student.id}'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
