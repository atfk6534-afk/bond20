import 'package:flutter_test/flutter_test.dart';

import 'package:bond2/core/database/database.dart';
import 'package:bond2/features/attendance/attendance_repository.dart';
import 'package:bond2/features/groups/groups_repository.dart';
import 'package:bond2/features/lessons/lessons_repository.dart';
import 'package:bond2/features/payments/payments_repository.dart';
import 'package:bond2/features/settings/settings_repository.dart';
import 'package:bond2/features/students/students_repository.dart';


String pastStartTime() {
  final t = DateTime.now().subtract(const Duration(minutes: 5));
  return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}

void main() {
  late AppDatabase db;
  late StudentsRepository studentsRepo;
  late LessonsRepository lessonsRepo;
  late AttendanceRepository attendanceRepo;
  late PaymentsRepository paymentsRepo;
  late GroupsRepository groupsRepo;
  late SettingsRepository settingsRepo;

  setUp(() {
    db = openTestDatabase();
    studentsRepo = StudentsRepository(db);
    lessonsRepo = LessonsRepository(db);
    attendanceRepo = AttendanceRepository(db);
    paymentsRepo = PaymentsRepository(db);
    groupsRepo = GroupsRepository(db);
    settingsRepo = SettingsRepository(db);
  });

  tearDown(() async {
    await db.close();
  });

  group('Academic year management', () {
    test('can add the next academic year and prevents duplicates', () async {
      await settingsRepo.addAcademicYear('2026/2027');
      expect(await settingsRepo.suggestNextAcademicYearName(), '2027/2028');
      await settingsRepo.addAcademicYear('2027/2028');
      expect(
        () => settingsRepo.addAcademicYear('2027/2028'),
        throwsArgumentError,
      );
    });
  });

  group('Auto-pay on attendance ("طالما حضر يبقى دفع")', () {
    test('marking present with autoPayOnAttendance records a full payment for the lesson charge', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 5000,
        explicitStudentIds: [studentId],
      );

      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.present, method: AttendanceMethod.manual,
        autoPayOnAttendance: true,
      );

      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalCharged, 5000);
      expect(balance.totalPaid, 5000);
      expect(balance.outstanding, 0);
    });

    test('is idempotent - toggling present/absent/present again never double-pays', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 5000,
        explicitStudentIds: [studentId],
      );

      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.present, method: AttendanceMethod.manual,
        autoPayOnAttendance: true,
      );
      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.absent, method: AttendanceMethod.manual,
        autoPayOnAttendance: true,
      );
      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.present, method: AttendanceMethod.manual,
        autoPayOnAttendance: true,
      );

      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalPaid, 5000); // never 10000 or 15000
      expect(balance.outstanding, 0);
    });

    test('only pays the REMAINING balance if the student already partially paid', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب دفع جزئي');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 10000,
        explicitStudentIds: [studentId],
      );
      final open = await paymentsRepo.openChargesFor(studentId);
      await paymentsRepo.recordPayment(
        studentId: studentId, amountPiastres: 4000,
        allocations: {open.first.charge.id: 4000},
      );

      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.present, method: AttendanceMethod.manual,
        autoPayOnAttendance: true,
      );

      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalPaid, 10000); // 4000 manual + 6000 auto = full
      expect(balance.outstanding, 0);
    });

    test('does nothing when the lesson is free (price 0)', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب حصة مجانية');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 0,
        explicitStudentIds: [studentId],
      );

      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.present, method: AttendanceMethod.manual,
        autoPayOnAttendance: true,
      );

      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalCharged, 0);
      expect(balance.totalPaid, 0);
    });

    test('marking ABSENT never triggers auto-pay, even if the flag is on', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب غائب');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 5000,
        explicitStudentIds: [studentId],
      );

      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.absent, method: AttendanceMethod.manual,
        autoPayOnAttendance: true,
      );

      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalPaid, 0);
      expect(balance.outstanding, 5000);
    });

    test('defaults to false (off) when autoPayOnAttendance is not passed - preserves old behavior', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب افتراضي');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 5000,
        explicitStudentIds: [studentId],
      );

      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.present, method: AttendanceMethod.manual,
      );

      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalPaid, 0); // no auto-pay happened
    });

    test('the setting itself defaults to false in a fresh database', () async {
      final settings = await settingsRepo.getOrCreateSettings();
      expect(settings.autoPayOnAttendance, isFalse);
    });

    test('setAutoPayOnAttendance persists the toggle', () async {
      await settingsRepo.setAutoPayOnAttendance(true);
      final settings = await settingsRepo.getOrCreateSettings();
      expect(settings.autoPayOnAttendance, isTrue);
    });
  });

  group('Manual charge ("إضافة مستحق")', () {
    test('adds a charge that correctly increases the outstanding balance', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب غرامة');
      await paymentsRepo.addManualCharge(
        studentId: studentId, description: 'غرامة تأخير', amountPiastres: 2000,
      );

      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalCharged, 2000);
      expect(balance.outstanding, 2000);
    });

    test('rejects a zero or negative amount', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      expect(
        () => paymentsRepo.addManualCharge(studentId: studentId, description: 'شيء', amountPiastres: 0),
        throwsA(isA<OverpaymentException>()),
      );
    });

    test('rejects an empty description', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      expect(
        () => paymentsRepo.addManualCharge(studentId: studentId, description: '  ', amountPiastres: 1000),
        throwsA(isA<OverpaymentException>()),
      );
    });

    test('a manual charge can be paid off exactly like any other charge', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      await paymentsRepo.addManualCharge(studentId: studentId, description: 'رسوم', amountPiastres: 3000);
      final open = await paymentsRepo.openChargesFor(studentId);
      await paymentsRepo.recordPayment(
        studentId: studentId, amountPiastres: 3000, allocations: {open.first.charge.id: 3000},
      );
      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.outstanding, 0);
    });
  });

  group('Delete payment (undo)', () {
    test('deleting a payment makes its charge unpaid again', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      await paymentsRepo.addManualCharge(studentId: studentId, description: 'رسوم', amountPiastres: 5000);
      final open = await paymentsRepo.openChargesFor(studentId);
      final paymentId = await paymentsRepo.recordPayment(
        studentId: studentId, amountPiastres: 5000, allocations: {open.first.charge.id: 5000},
      );

      var balance = await studentsRepo.balanceFor(studentId);
      expect(balance.outstanding, 0);

      await paymentsRepo.deletePayment(paymentId);

      balance = await studentsRepo.balanceFor(studentId);
      expect(balance.outstanding, 5000);
      expect(balance.totalPaid, 0);
    });
  });

  group('Delete group', () {
    test('deleting a group does NOT delete its students, lessons, or attendance', () async {
      final yearId = await settingsRepo.addAcademicYear('2025/2026');
      final groupId = await groupsRepo.addGroup(name: 'مجموعة للحذف', academicYearId: yearId);
      final studentId = await studentsRepo.addStudent(name: 'طالب بالمجموعة', groupId: groupId);
      final lessonId = await lessonsRepo.createLesson(
        groupId: groupId, date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 1000,
      );

      await groupsRepo.deleteGroup(groupId);

      final student = await studentsRepo.byId(studentId);
      expect(student, isNotNull); // still exists
      expect(student!.groupId, isNull); // just detached

      final lesson = await (db.select(db.lessons)..where((t) => t.id.equals(lessonId))).getSingleOrNull();
      expect(lesson, isNotNull); // still exists
      expect(lesson!.groupId, isNull);
    });
  });

  group('Delete lesson', () {
    test('deletes a lesson with no payments, including its charges', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 5000,
        explicitStudentIds: [studentId],
      );

      final result = await lessonsRepo.deleteLesson(lessonId);
      expect(result.success, isTrue);

      final lesson = await (db.select(db.lessons)..where((t) => t.id.equals(lessonId))).getSingleOrNull();
      expect(lesson, isNull);

      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalCharged, 0); // the charge was removed too
    });

    test('BLOCKS deleting a lesson that already has a payment recorded', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب دفع');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 5000,
        explicitStudentIds: [studentId],
      );
      final open = await paymentsRepo.openChargesFor(studentId);
      await paymentsRepo.recordPayment(
        studentId: studentId, amountPiastres: 5000, allocations: {open.first.charge.id: 5000},
      );

      final result = await lessonsRepo.deleteLesson(lessonId);
      expect(result.success, isFalse);
      expect(result.error, isNotNull);

      final lesson = await (db.select(db.lessons)..where((t) => t.id.equals(lessonId))).getSingleOrNull();
      expect(lesson, isNotNull); // untouched
      final balance = await studentsRepo.balanceFor(studentId);
      expect(balance.totalPaid, 5000); // payment history intact
    });

    test('deleting a lesson removes its attendance records too', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 0,
        explicitStudentIds: [studentId],
      );
      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.present, method: AttendanceMethod.manual,
      );

      final result = await lessonsRepo.deleteLesson(lessonId);
      expect(result.success, isTrue);

      final records = await (db.select(db.attendanceRecords)..where((t) => t.lessonId.equals(lessonId))).get();
      expect(records, isEmpty);
    });
  });

  group('Permanent student delete', () {
    test('cascades to remove attendance, charges, and payments, leaving no orphans', () async {
      final studentId = await studentsRepo.addStudent(name: 'طالب للحذف النهائي');
      final lessonId = await lessonsRepo.createLesson(
        date: DateTime.now(), startTime: pastStartTime(), pricePiastres: 5000,
        explicitStudentIds: [studentId],
      );
      await attendanceRepo.markAttendance(
        lessonId: lessonId, studentId: studentId,
        status: AttendanceStatus.present, method: AttendanceMethod.manual,
        autoPayOnAttendance: true,
      );

      await studentsRepo.permanentlyDeleteStudent(studentId);

      final student = await studentsRepo.byId(studentId);
      expect(student, isNull);

      final charges = await (db.select(db.charges)..where((t) => t.studentId.equals(studentId))).get();
      expect(charges, isEmpty);
      final payments = await (db.select(db.payments)..where((t) => t.studentId.equals(studentId))).get();
      expect(payments, isEmpty);
      final attendance = await (db.select(db.attendanceRecords)..where((t) => t.studentId.equals(studentId))).get();
      expect(attendance, isEmpty);

      // The lesson itself (and other students' data, if any) is untouched.
      final lesson = await (db.select(db.lessons)..where((t) => t.id.equals(lessonId))).getSingleOrNull();
      expect(lesson, isNotNull);
    });

    test('does not affect other students\' data', () async {
      final s1 = await studentsRepo.addStudent(name: 'يُحذف');
      final s2 = await studentsRepo.addStudent(name: 'يبقى');
      await paymentsRepo.addManualCharge(studentId: s1, description: 'x', amountPiastres: 1000);
      await paymentsRepo.addManualCharge(studentId: s2, description: 'y', amountPiastres: 2000);

      await studentsRepo.permanentlyDeleteStudent(s1);

      final balance2 = await studentsRepo.balanceFor(s2);
      expect(balance2.totalCharged, 2000); // unaffected
    });
  });
}
