import 'package:flutter/material.dart';

/// BOND2 visual identity: calm blue/teal primary, rounded cards,
/// generous spacing, large touch targets — designed for a teacher
/// tapping quickly during a live lesson (rule #59-61).
class AppTheme {
  const AppTheme._();

  static const Color _seed = Color(0xFF2F6F63); // teal-green, calm & trustworthy
  static const Color success = Color(0xFF2E7D32);
  static const Color warning = Color(0xFFB8860B);
  static const Color danger = Color(0xFFC62828);

  static ThemeData light() => _base(Brightness.light);
  static ThemeData dark() => _base(Brightness.dark);

  static ThemeData _base(Brightness brightness) {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: _seed,
      brightness: brightness,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      // NOTE: no custom `fontFamily` is set here. An earlier version of
      // this file claimed `fontFamily: 'Cairo'`, but that font was never
      // actually bundled in assets/pubspec.yaml - Flutter would have
      // silently fallen back to the platform default anyway, which is
      // misleading (rule #91 - don't claim something that isn't really
      // there). We DO bundle a real Arabic font (Amiri, OFL-licensed,
      // assets/fonts/) for PDF export, but Amiri is a formal Naskh/print
      // typeface, not a great fit for everyday UI chrome. Leaving
      // fontFamily unset lets each platform use its own default font,
      // which on Android/iOS both include proper Arabic-script fallback
      // rendering out of the box.
      visualDensity: VisualDensity.comfortable,
      cardTheme: CardTheme(
        elevation: 0,
        color: colorScheme.surfaceContainerHigh,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        margin: const EdgeInsets.symmetric(vertical: 6),
      ),
      appBarTheme: AppBarTheme(
        centerTitle: true,
        backgroundColor: colorScheme.surface,
        foregroundColor: colorScheme.onSurface,
        elevation: 0,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: colorScheme.surfaceContainerHighest,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 66,
        backgroundColor: colorScheme.surface,
        indicatorColor: colorScheme.primaryContainer,
      ),
      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
    );
  }
}

/// Semantic colors for payment/attendance status — never relies on
/// color alone (rule #31, #61); always paired with text/icon.
class StatusColors {
  const StatusColors._();

  static Color paid(BuildContext c) => AppTheme.success;
  static Color partial(BuildContext c) => AppTheme.warning;
  static Color unpaid(BuildContext c) => AppTheme.danger;
}
