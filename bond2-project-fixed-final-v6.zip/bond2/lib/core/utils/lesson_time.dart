import '../database/database.dart';

/// Returns true once the lesson's scheduled start date/time has arrived.
/// Attendance is intentionally blocked before this point so a future lesson
/// can never be marked as attended or auto-paid by mistake.
bool lessonHasStarted(Lesson lesson, {DateTime? now}) {
  final current = now ?? DateTime.now();
  final parts = lesson.startTime.split(':');
  final hour = parts.isNotEmpty ? int.tryParse(parts[0]) ?? 0 : 0;
  final minute = parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0;
  final start = DateTime(
    lesson.date.year,
    lesson.date.month,
    lesson.date.day,
    hour,
    minute,
  );
  return !start.isAfter(current);
}
